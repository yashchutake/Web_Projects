<!--header area-->
<?php include 'theme/header.php'; ?>
<!--sidebar area-->

<?php include 'theme/body.php'; ?>
          <!-- Breadcrumbs-->
<!--breadcrumbs area-->

          <!-- Area Chart Example-->
             <!-- Area Chart area-->

          <!-- DataTables Example -->
            <!-- datatable area-->

      <!--footer area-->
      <center>
<?php include 'theme/footer.php'; ?>
</center>