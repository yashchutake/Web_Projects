

    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-home"></i>
            <span>Home</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="sports.php">
            <i class="fas fa-fw fa-question"></i>
            <span>About US</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="match.php">
            <i class="fas fa-fw fa-phone"></i>
            <span>Contact US</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="result.php">
            <i class="fas fa-fw fa-calendar-check"></i>
            <span>Game Result</span></a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="result.php">
            <i class="fas fa-fw fa-calendar"></i>
            <span>Game Schedule</span></a>
        </li>
      </ul>

            <div id="content-wrapper">

        <div class="container-fluid">