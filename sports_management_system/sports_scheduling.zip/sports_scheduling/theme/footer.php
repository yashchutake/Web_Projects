<footer id="footer" class="bg-info">
 <a class="scroll-to-top rounded" href="#page-top" style="display: inline;">
      <i class="fas fa-angle-up"></i>
    </a>
    <div class="align-center">
        <br>
    <a href="team.php" style="margin: 1%;color: #000">Team Game</a>
    <a href="single.php" style="margin: 1%;color: #000">Single Game</a>
    <a href="double.php" style="margin: 1%;color: #000">Double Game</a>
    <br>
    <br>
    <br>
</div>
				<div class="copyright">
					<p class="fas fa-basketball-ball">&copy; All rights reserved. Sports Scheduling and Result Monitoring 2020</p>
				</div>
</footer>
		<!-- Scripts -->
		 <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>