<!--header area-->
<?php include 'theme/header.php'; ?>
<!--sidebar area-->
<?php include 'theme/sidebar.php'; ?>


          <!-- Breadcrumbs-->
<!--breadcrumbs area-->
<?php include 'theme/breadcrumbs.php'; ?>
          <!-- Icon Cards-->
         <!--Icon Card area-->
<?php include 'theme/iconcards.php'; ?>
          <!-- Area Chart Example-->
             <!-- Area Chart area-->
             <center>
        <div style="margin-top: -130px">
            <img src="../cover_image.jpg" alt="..." style="width: 100%;">
          </div>
        </center>
      <!--footer area-->
<?php include 'theme/footer.php'; ?>